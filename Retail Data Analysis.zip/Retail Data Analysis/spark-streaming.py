#Importing the necessary libraries
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

#Below code is for starting a spark session
spark = SparkSession \
        .builder \
        .appName("RetailProjectAnalysis") \
        .getOrCreate()
spark.sparkContext.setLogLevel('ERROR')

#Below code is for reading from a Kafka stream
reading_stream = spark \
                 .readStream \
                 .format("kafka") \
                 .option("kafka.bootstrap.servers", "18.211.252.152:9092") \
                 .option("subscribe", "real-time-project") \
                 .option("startingOffsets", "latest") \
                 .load()

#UDF for calculating total cost
def get_total_cost(items, type):
    total_cost = 0
    for item in items:
        if type == 'ORDER':
            total_cost = total_cost + (item['quantity']*item['unit_price'])
        else:
            total_cost = total_cost - (item['quantity']*item['unit_price'])
    return total_cost

#UDF for calculating total number of items
def get_total_no_of_items(items):
    item_count = 0
    for item in items:
        item_count = item_count + item['quantity']  
    return item_count

#UDF for fidnding out if it is an order type 
def is_order(type):
    flag = 0
    if type == 'ORDER':
        flag = 1
    else:
        flag = 0
    return flag

#UDF for fidnding out if it is an return type 
def is_return(type):
    flag = 0
    if type == 'RETURN':
        flag = 1
    else:
        flag = 0
    return flag

#Below code is for creating additional attribute which we will create with the help of UDF
#Lets get the UDF using the utility function
get_total_cost_udf = udf(get_total_cost, DoubleType())
get_total_no_of_items_udf = udf(get_total_no_of_items, IntegerType())
is_order_udf = udf(is_order, IntegerType())
is_return_udf = udf(is_return, IntegerType())

#Lets create the JSON schema for a order
orderSchema = StructType() \
              .add("invoice_no", LongType()) \
              .add("country", StringType()) \
              .add("timestamp", TimestampType()) \
              .add("type", StringType()) \
              .add("items", ArrayType(StructType([
                StructField("SKU", StringType()),
                StructField("title", StringType()),
                StructField("unit_price", DoubleType()),
                StructField("quantity", IntegerType())
              ])))

#Lets parse the streaming data and apply the schema on it
#we imposed the schema and then gave it a name called streamdata and then we are fetching all the data from it from all of its columns 
reading_stream_final = reading_stream.select(from_json(col("value").cast("string"), orderSchema).alias("streamdata")).select("streamdata.*")

#Getting the required attribute which we generated using UDF and getting the final set of columns
Data_Frame = reading_stream_final \
             .withColumn("total_cost", get_total_cost_udf(reading_stream_final.items, reading_stream_final.type)) \
             .withColumn("total_items", get_total_no_of_items_udf(reading_stream_final.items)) \
             .withColumn("is_order", is_order_udf(reading_stream_final.type)) \
             .withColumn("is_return", is_return_udf(reading_stream_final.type)).select("invoice_no", "country", "timestamp", "total_cost", "total_items", "is_order", "is_return")

#Writing the intermediary output to console
query = Data_Frame \
        .writeStream \
        .outputMode("append") \
        .format("console") \
        .option("truncate", "false") \
        .trigger(processingTime = "1 minute") \
        .start()

#Lets calculate time-based KPIs
timeBasedKpi = Data_Frame \
               .withWatermark("timestamp", "1 minute") \
               .groupBy(window("timestamp", "10 minutes", "1 minute")) \
               .agg(
                    count("invoice_no").alias("OPM"),
                    sum("total_cost").alias("total_sale_volume"),
                    avg("is_return").alias("rate_of_return"),
                    avg("total_cost").alias("average_transaction_size")
                ) \
               .select("window.start", "window.end", "OPM", "total_sale_volume", "average_transaction_size", "rate_of_return")

#Lets calculate country based KPIs
countryBasedKpi = Data_Frame \
                  .withWatermark("timestamp", "1 minute") \
                  .groupBy(window("timestamp", "10 minutes", "1 minute"),"country") \
                  .agg(
                       count("invoice_no").alias("OPM"),
                       sum("total_cost").alias("total_sale_volume"),
                       avg("is_return").alias("rate_of_return")
                   ) \
                  .select("window.start", "window.end", "country", "OPM", "total_sale_volume", "rate_of_return")

#Writing time-based KPIs to HDFS
queryByTime = timeBasedKpi \
              .writeStream \
              .format("json") \
              .outputMode("append") \
              .option("truncate", "false") \
              .option("path", "Timebased-KPI") \
              .option("checkpointLocation", "time-cp") \
              .trigger(processingTime = "1 minute") \
              .start()                         

                     
#Writing country based KPIs to HDFS
queryByCountry = countryBasedKpi \
                 .writeStream \
                 .format("json") \
                 .outputMode("append") \
                 .option("truncate", "false") \
                 .option("path", "Country-and-timebased-KPI") \
                 .option("checkpointLocation", "time-country-cp") \
                 .trigger(processingTime = "1 minute") \
                 .start()

#For waiting indefinitely to read the data
query.awaitTermination()
queryByTime.awaitTermination()
queryByCountry.awaitTermination()
